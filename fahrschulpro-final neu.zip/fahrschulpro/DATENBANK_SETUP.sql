-- ── TABELLEN ───────────────────────────────────────────────────────────

-- Schüler
CREATE TABLE schueler (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  pin TEXT NOT NULL,
  erstellt_am TIMESTAMP DEFAULT NOW()
);

-- Themen-Status pro Schüler
CREATE TABLE themen_status (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  schueler_id UUID REFERENCES schueler(id) ON DELETE CASCADE,
  thema_name TEXT NOT NULL,
  status TEXT DEFAULT 'offen',
  aktualisiert_am TIMESTAMP DEFAULT NOW(),
  UNIQUE(schueler_id, thema_name)
);

-- Fahrstunden
CREATE TABLE fahrstunden (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  schueler_id UUID REFERENCES schueler(id) ON DELETE CASCADE,
  datum DATE NOT NULL,
  bewertung INTEGER DEFAULT 0,
  notiz TEXT,
  erstellt_am TIMESTAMP DEFAULT NOW()
);

-- Themen-Lernmaterial (Videos & Aufgaben)
CREATE TABLE themen_material (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  thema_name TEXT NOT NULL UNIQUE,
  gruppe_name TEXT NOT NULL,
  video_url TEXT DEFAULT '',
  aufgaben JSONB DEFAULT '[]',
  aktualisiert_am TIMESTAMP DEFAULT NOW()
);

-- ── SICHERHEIT (Row Level Security) ──────────────────────────────────
ALTER TABLE schueler ENABLE ROW LEVEL SECURITY;
ALTER TABLE themen_status ENABLE ROW LEVEL SECURITY;
ALTER TABLE fahrstunden ENABLE ROW LEVEL SECURITY;
ALTER TABLE themen_material ENABLE ROW LEVEL SECURITY;

-- Alle dürfen alles lesen und schreiben (für diese App ausreichend)
CREATE POLICY "allow_all" ON schueler FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON themen_status FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON fahrstunden FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON themen_material FOR ALL USING (true) WITH CHECK (true);

-- ── BEISPIELDATEN ─────────────────────────────────────────────────────
INSERT INTO themen_material (thema_name, gruppe_name, video_url, aufgaben) VALUES
('Anfahren & Anhalten', 'Grundfahraufgaben', '', '[
  {"id":"a1","type":"multiple_choice","question":"Was musst du vor dem Anfahren prüfen?","options":["Spiegel, Schulterblick, Blinker","Nur Rückspiegel","Direkt losfahren","Hupen"],"correctAnswer":0,"explanation":"Immer: Spiegel – Schulterblick – Blinker."},
  {"id":"a2","type":"true_false","question":"Beim Anhalten muss man immer die Handbremse ziehen.","correctAnswer":false,"explanation":"Nur beim Parken oder längeren Stehen."}
]'),
('Autobahn', 'Streckenprofil', '', '[
  {"id":"a3","type":"multiple_choice","question":"Richtgeschwindigkeit auf der Autobahn?","options":["100 km/h","120 km/h","130 km/h","150 km/h"],"correctAnswer":2,"explanation":"Richtgeschwindigkeit 130 km/h."},
  {"id":"a4","type":"true_false","question":"Auf der Autobahn darf man links überholen.","correctAnswer":true,"explanation":"Überholen ist nur links erlaubt."}
]'),
('Vorfahrtsregeln', 'Vorfahrt & Verkehrsregeln', '', '[
  {"id":"a5","type":"multiple_choice","question":"Wer hat bei gleicher Straßenbreite Vorfahrt?","options":["Von links","Von rechts","Geradeaus","Niemand"],"correctAnswer":1,"explanation":"Rechts vor links."}
]');
