import { useState, useEffect } from "react";
import { supabase } from "./supabase";

const C = {
  bg:"#0f1923", surface:"#1a2638", card:"#1e2e42",
  accent:"#e63946", blue:"#3a86ff", green:"#10b981",
  orange:"#f59e0b", muted:"#8fa3b8", border:"#2a3f5a", text:"#e8f0f8",
  purple:"#8b5cf6", cyan:"#06b6d4",
};

const AUSBILDUNG = [
  { id:"schaltkompetenz", label:"Schaltkompetenz", icon:"⚙️", color:"#f59e0b", gruppen:[
    { name:"Schaltübungen", items:["Hoch schalten","Runter schalten","Gänge überspringen"] },
    { name:"Fahrzeugbedienung", items:["Pedal Manuell","Rollen und Schalten","Abbremsen und Schalten","Tastgeschwindigkeit"] },
    { name:"Gefälle/Steigung", items:["Anhalten","Anfahren","Rückwärts","Sichern","Schalten"] },
  ]},
  { id:"grundstufe", label:"Grundstufe", icon:"📗", color:"#10b981", gruppen:[
    { name:"Einstellen", items:["Sitz","Spiegel","Lenkrad","Kopfstütze"] },
    { name:"Fahrzeugbedienung", items:["Lenkradhaltung","Pedale Bedienen","Gurt anlegen/anpassen","Lenkradsperre Entriegeln","Lenkradsperre Verriegeln","Anfahr-/Anhaltübung","Lenkübung"] },
  ]},
  { id:"aufbaustufe", label:"Aufbaustufe", icon:"📘", color:"#3a86ff", gruppen:[
    { name:"Bremsübungen", items:["Degressives Bremsen","Zielbremsung"] },
    { name:"Fahrbahnbenutzung", items:["Einordnen","Markierung"] },
  ]},
  { id:"leistungsstufe", label:"Leistungsstufe", icon:"📙", color:"#e63946", gruppen:[
    { name:"Spiegel, Blinker, Schulterblick", items:["Fahrstreifenwechsel","Hindernisse/Überholen","Abbiegen","Anfahren"] },
    { name:"Abbiegen", items:["Rechts","Links","Mehrspurig","Sonderstreifen","Einbahnstraßen"] },
    { name:"Geschwindigkeit", items:["Zone","Abbiegen","Inner-/Außerorts","Baustelle + Geschwindigkeit"] },
    { name:"Vorfahrt/Vorrang", items:["Polizeibeamte","Linksabbieger Regel"] },
    { name:"Ampel", items:["Normale Ampel","Pfeilampel","Normale + Pfeilampel","Normale + Räumungspfeil","Grünpfeilschild","2 Phasen Ampel","Linksabbieger Regel"] },
    { name:"Verkehrszeichen Vorfahrt", items:["Vorfahrt gewähren","Stoppschild","Einmalige Vorfahrt","Vorfahrtsstraße","Abknickende Vorfahrt","Linksabbieger Regel"] },
    { name:"Rechts vor Links", items:["Mäßige Geschwindigkeit","Linksabbieger Regel"] },
    { name:"Situationen mit anderen Verkehrsteilnehmern", items:["Fußgängerüberweg","Ältere/Behinderte","Kinder","Schulbus","Radfahrer","Verkehrsberuhigter Bereich","Einsatzfahrzeuge"] },
    { name:"Fahrradstraße", items:["Geschwindigkeit","Freigabe für Kfz","Beschränkte Freigabe für Kfz"] },
    { name:"Engpässe", items:["Geschwindigkeit","Beobachtung","Abstand"] },
    { name:"Kreisverkehr", items:["Kreisverkehr"] },
    { name:"Bahnübergang", items:["Warten","Überqueren"] },
    { name:"Partnerschaftliches Verhalten", items:["Partnerschaftliches Verhalten"] },
    { name:"Fahrbahnverengung", items:["2 Spuren münden in 1 Spur","1 Spur mündet in mehrere Spuren"] },
    { name:"Weitere Verkehrszeichen", items:["Weitere Verkehrszeichen"] },
  ]},
  { id:"grundfahraufgaben", label:"Grundfahraufgaben", icon:"🎯", color:"#8b5cf6", gruppen:[
    { name:"Rückwärtsfahren", items:["Rückwärts um die Ecke"] },
    { name:"Umkehren", items:["Einfahrt","Kreisverkehr","Wendekreis","Wendehammer"] },
    { name:"Einparken Längs", items:["Vorwärts Rechts","Vorwärts Links","Rückwärts Rechts","Rückwärts Links"] },
    { name:"Einparken Quer (Box)", items:["Vorwärts Rechts","Vorwärts Links","Rückwärts Rechts","Rückwärts Links"] },
    { name:"Gefahrenbremsung", items:["Geschwindigkeit (30 km/h)","Spiegel Blinker Schulterblick","Ansage/Abbrechen"] },
  ]},
  { id:"pruefungssimulation", label:"Prüfungssimulation", icon:"📝", color:"#ec4899", gruppen:[
    { name:"Prüfungsfragen", items:["Beobachtung","Geschwindigkeit","Rechts vor Links","Linksabbieger Regel","Stoppschild","Verbotszeichen"] },
  ]},
  { id:"technik", label:"Technik", icon:"🔧", color:"#6b7c93", gruppen:[
    { name:"Motorraum/Flüssigkeitsstände", items:["Kühlflüssigkeit","Motoröl","Scheibenwischwasser","Bremsflüssigkeit"] },
    { name:"Reifen", items:["Mindestprofiltiefe","Luftdruck","Beschädigung","Winter-/Sommerreifen"] },
    { name:"Bremsprobe", items:["Betriebsbremse","Feststellbremse"] },
    { name:"Beleuchtung", items:["Standlicht","Abblendlicht","Automatisches Abblendlicht","Schlechtwetterscheinwerfer","Nebelschlussleuchte","Fernlicht/Lichthupe","Warnblinkanlage","Bremslicht","Rückfahrscheinwerfer","Reflektoren/Rückstrahler"] },
  ]},
  { id:"sonderfahrten", label:"Sonderfahrten", icon:"🚨", color:"#06b6d4", gruppen:[
    { name:"Überlandfahrten (5)", items:["Abstände vorne/hinten","Beobachtung Spiegel","Verkehrszeichen","Kurven","Steigung","Gefälle","Alleen","Überholen","Geschwindigkeit","Einfahren in eine Ortschaft","Ablenkung (z.B. Radio)","Orientierung"] },
    { name:"Autobahnfahrten (4)", items:["Fahrtplanung","Einfahren BAB","Fahrstreifenwechsel","Geschwindigkeit","Abstände vorne/hinten","Überholen","Schilder/Markierung","Rast-/Parkplätze Tankstellen","Verhalten bei Unfällen","Dichter Verkehr/Stau","Leistungsgrenze","Ablenkung","Tempomat","Verlassen BAB"] },
    { name:"Beleuchtungsfahrten (3)", items:["Beleuchtung Einschalten","Beleuchtung Kontrollieren","Beleuchtete Straße","Unbeleuchtete Straßen","Parken","Bahnübergang","Schlechte Witterung","Unbeleuchtete Verkehrsteilnehmer","Tiere/Wild","Orientierung","Blendung","Abschlussgespräch"] },
  ]},
];

const ALL_ITEMS = AUSBILDUNG.flatMap(s=>s.gruppen.flatMap(g=>g.items.map(i=>`${s.id}::${g.name}::${i}`)));

const STUFEN = [
  { value:0, fill:0,   color:"#2a3f5a", bg:"transparent" },
  { value:1, fill:0.5, color:"#f59e0b", bg:"rgba(245,158,11,0.08)" },
  { value:2, fill:1,   color:"#10b981", bg:"rgba(16,185,129,0.1)" },
];
const nextStufe = cur => ((cur||0)+1)%3;
const getStufe = val => STUFEN[val||0];
const KLASSEN = ["B","BE","B96","AM","A1","A2","A","C","CE","C1","C1E","D","DE","T","L"];

// Status OHNE "in_ausbildung"
const SCHUELER_STATUS = {
  aktiv:         { label:"Aktiv",         color:"#10b981", bg:"rgba(16,185,129,0.15)", icon:"🟢" },
  abgeschlossen: { label:"Abgeschlossen", color:"#8b5cf6", bg:"rgba(139,92,246,0.15)", icon:"✅" },
  archiviert:    { label:"Archiviert",    color:"#8fa3b8", bg:"rgba(148,163,184,0.1)", icon:"📦" },
};

// Demo Lernmaterial pro Thema
const INIT_MATERIAL = {
  "schaltkompetenz::Schaltübungen": {
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    fotos: [],
    quiz: [
      { id:"q1", frage:"Wann schaltest du in den nächsten Gang?", typ:"mc", antworten:["Bei hoher Drehzahl","Immer bei 50 km/h","Nur auf der Autobahn","Nach 10 Sekunden"], richtig:0, erklaerung:"Beim Hochschalten orientiert man sich an der Motordrehzahl." },
      { id:"q2", frage:"Muss man beim Hochschalten die Kupplung treten?", typ:"wf", richtig:true, erklaerung:"Ja, immer Kupplung treten bevor du schaltest." },
    ],
  },
  "grundstufe::Einstellen": {
    videoUrl: "",
    fotos: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600"],
    quiz: [
      { id:"q3", frage:"Wie weit sollte dein Arm beim korrekten Sitzabstand gestreckt sein?", typ:"mc", antworten:["Vollständig gestreckt","Leicht gebeugt","Stark gebeugt","Spielt keine Rolle"], richtig:1, erklaerung:"Der Arm soll leicht gebeugt sein wenn du das Lenkrad hältst." },
    ],
  },
};

const INIT_SCHUELER = [
  { id:"s1", name:"Max Mustermann", pin:"1234", status:"aktiv",
    info:{ klassen:["B","BE"], sehhilfe:"Brille", theorie:true, fahrlehrer:"Max Mustermann", notizen:[
      {id:"n1",text:"Grundstufe sehr gut abgeschlossen. Aufbaustufe beginnen.",datum:"2024-05-17"},
    ]},
    themen:{
      "grundstufe::Einstellen::Sitz":2,
      "grundstufe::Einstellen::Spiegel":2,
      "grundstufe::Einstellen::Lenkrad":1,
      "schaltkompetenz::Schaltübungen::Hoch schalten":1,
    }},
  { id:"s2", name:"Anna Schmidt", pin:"5678", status:"aktiv",
    info:{ klassen:["B"], sehhilfe:"Keine", theorie:false, fahrlehrer:"Max Mustermann", notizen:[] },
    themen:{"grundstufe::Einstellen::Sitz":2}},
  { id:"s3", name:"Jonas Weber", pin:"1111", status:"abgeschlossen",
    info:{ klassen:["B"], sehhilfe:"Keine", theorie:true, fahrlehrer:"Max Mustermann", notizen:[
      {id:"n2",text:"Prüfung bestanden! Herzlichen Glückwunsch!",datum:"2024-03-15"},
    ]},
    themen:{}},
];

function FillBar({value,onClick,readonly}) {
  const st=getStufe(value);
  return (
    <div onClick={readonly?undefined:onClick}
      style={{width:72,height:10,background:"#1a2638",borderRadius:99,overflow:"hidden",cursor:readonly?"default":"pointer",flexShrink:0,border:`1px solid ${value>0?st.color+"66":C.border}`}}>
      <div style={{height:"100%",borderRadius:99,width:`${st.fill*100}%`,background:st.color,transition:"width .2s, background .2s",boxShadow:value>0?`0 0 5px ${st.color}88`:"none"}}/>
    </div>
  );
}

function ProgressRing({pct,size=64,stroke=6}) {
  const r=(size-stroke*2)/2,circ=2*Math.PI*r;
  const col=pct>=80?C.green:pct>=40?C.orange:C.accent;
  return (
    <svg width={size} height={size} style={{transform:"rotate(-90deg)"}}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth={stroke}/>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={col} strokeWidth={stroke}
        strokeDasharray={circ} strokeDashoffset={circ*(1-pct/100)} strokeLinecap="round" style={{transition:"stroke-dashoffset .5s"}}/>
    </svg>
  );
}

export default function App() {
  const [user,setUser]=useState(null);
  const [loginName,setLoginName]=useState("");
  const [loginPin,setLoginPin]=useState("");
  const [loginErr,setLoginErr]=useState("");
  const [schuelerList,setSchuelerList]=useState(INIT_SCHUELER);
  const [material,setMaterial]=useState({});

  // Lernmaterial aus Supabase laden
  useEffect(()=>{
    const ladeMaterial=async()=>{
      const [matRes,quizRes]=await Promise.all([
        supabase.from("lernmaterial").select("*"),
        supabase.from("quiz_fragen").select("*"),
      ]);
      const map={};
      (matRes.data||[]).forEach(m=>{
        map[m.item_key]={videoUrl:m.video_url||"",fotos:m.fotos||[],quiz:[]};
      });
      (quizRes.data||[]).forEach(q=>{
        if(!map[q.item_key]) map[q.item_key]={videoUrl:"",fotos:[],quiz:[]};
        map[q.item_key].quiz.push({id:q.id,frage:q.frage,typ:q.typ,antworten:q.antworten||[],richtig:q.richtig,erklaerung:q.erklaerung||""});
      });
      setMaterial(map);
    };
    ladeMaterial();
  },[]);

  const login=()=>{
    if(loginName.trim().toLowerCase()==="lehrer"&&loginPin==="9999"){setUser({role:"lehrer"});return;}
    const found=schuelerList.find(s=>s.name.toLowerCase()===loginName.trim().toLowerCase()&&s.pin===loginPin);
    if(found){setUser({role:"schueler",id:found.id});return;}
    setLoginErr("Name oder PIN falsch.");
  };
  const logout=()=>{setUser(null);setLoginName("");setLoginPin("");setLoginErr("");};
  const toggleItem=(schuelerId,key)=>{
    setSchuelerList(prev=>prev.map(s=>s.id!==schuelerId?s:{...s,themen:{...s.themen,[key]:nextStufe(s.themen[key]||0)}}));
  };
  const statusAendern=(id,neuerStatus)=>{
    setSchuelerList(prev=>prev.map(s=>s.id!==id?s:{...s,status:neuerStatus}));
  };
  const loescheSchueler=(id)=>{
    setSchuelerList(prev=>prev.filter(s=>s.id!==id));
  };

  if(!user) return <LoginScreen name={loginName} setName={setLoginName} pin={loginPin} setPin={setLoginPin} err={loginErr} onLogin={login}/>;
  if(user.role==="lehrer") return <LehrerApp schuelerList={schuelerList} setSchuelerList={setSchuelerList} onToggleItem={toggleItem} onStatusAendern={statusAendern} onLoescheSchueler={loescheSchueler} material={material} setMaterial={setMaterial} onLogout={logout}/>;
  return <SchuelerApp schueler={schuelerList.find(s=>s.id===user.id)} material={material} onLogout={logout}/>;
}

function LoginScreen({name,setName,pin,setPin,err,onLogin}) {
  return (
    <div style={{minHeight:"100vh",background:C.bg,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24}}>
      <div style={{textAlign:"center",marginBottom:32}}>
        <div style={{fontSize:56,marginBottom:8}}>🚗</div>
        <div style={{fontSize:30,fontWeight:900}}>FahrSchul<span style={{color:C.accent}}>Pro</span></div>
        <div style={{color:C.muted,fontSize:14,marginTop:6}}>Ausbildung · Lernmaterial · Fortschritt</div>
      </div>
      <div style={{background:C.surface,borderRadius:20,padding:32,width:"100%",maxWidth:360,boxShadow:"0 12px 48px rgba(0,0,0,0.5)"}}>
        <div style={{fontWeight:800,fontSize:20,marginBottom:20}}>Anmelden</div>
        <div style={{marginBottom:14}}><label style={lbl}>Name</label>
          <input value={name} onChange={e=>setName(e.target.value)} placeholder='"Max Mustermann" oder "Lehrer"' style={inp} onKeyDown={e=>e.key==="Enter"&&onLogin()}/>
        </div>
        <div style={{marginBottom:20}}><label style={lbl}>PIN</label>
          <input value={pin} onChange={e=>setPin(e.target.value)} type="password" maxLength={8} style={{...inp,letterSpacing:4}} onKeyDown={e=>e.key==="Enter"&&onLogin()}/>
        </div>
        {err&&<div style={{background:"#fde8ea",color:C.accent,borderRadius:8,padding:"10px 14px",fontSize:13,marginBottom:14}}>{err}</div>}
        <button onClick={onLogin} style={{...pBtn,width:"100%",padding:"13px",fontSize:16}}>Anmelden →</button>
        <div style={{marginTop:16,padding:12,background:"rgba(255,255,255,0.04)",borderRadius:8,fontSize:12,color:C.muted}}>
          Demo: Lehrer PIN 9999 · Max PIN 1234 · Anna PIN 5678
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// LEHRER APP
// ══════════════════════════════════════════════════════════════════════
function LehrerApp({schuelerList,setSchuelerList,onToggleItem,onStatusAendern,onLoescheSchueler,material,setMaterial,onLogout}) {
  const [view,setView]=useState("home");
  const [selId,setSelId]=useState(null);
  const [selItem,setSelItem]=useState(null);
  const [dashTab,setDashTab]=useState("aktiv");

  const aktiveSchueler=schuelerList.filter(s=>!["archiviert","abgeschlossen"].includes(s.status||"aktiv"));
  const archivSchueler=schuelerList.filter(s=>["archiviert","abgeschlossen"].includes(s.status||"aktiv"));
  const live=selId?schuelerList.find(s=>s.id===selId):null;

  const openSchueler=s=>{setSelId(s.id);setView("diagramm");};
  const openLernmaterial=(itemKey)=>{setSelItem(itemKey);setView("lernmaterial");};
  const goBack=()=>{
    if(view==="lernmaterial") setView("diagramm");
    else setView("home");
  };
  const neuerSchueler=(name,pin)=>{
    setSchuelerList(prev=>[...prev,{id:"s"+Date.now(),name,pin,status:"aktiv",info:{klassen:[],sehhilfe:"Keine",theorie:false,fahrlehrer:"",notizen:[]},themen:{}}]);
  };

  return (
    <div style={{minHeight:"100vh",background:C.bg,fontFamily:"'Segoe UI',sans-serif",color:C.text}}>
      <div style={{background:C.surface,borderBottom:`3px solid ${C.accent}`,padding:"14px 20px",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,zIndex:10}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{fontWeight:900,fontSize:20}}>FahrSchul<span style={{color:C.accent}}>Pro</span></div>
          <span style={{background:C.accent,color:"#fff",borderRadius:20,padding:"2px 10px",fontSize:11,fontWeight:700}}>LEHRER</span>
        </div>
        <div style={{display:"flex",gap:8}}>
          {view!=="home"&&<button onClick={goBack} style={gBtn}>← Zurück</button>}
          <button onClick={onLogout} style={gBtn}>Abmelden</button>
        </div>
      </div>
      {view==="home"         &&<LehrerHome schuelerList={schuelerList} aktiveSchueler={aktiveSchueler} archivSchueler={archivSchueler} dashTab={dashTab} setDashTab={setDashTab} setView={setView} onOpenSchueler={openSchueler} onStatusAendern={onStatusAendern} onLoescheSchueler={onLoescheSchueler} onNeuerSchueler={neuerSchueler}/>}
      {view==="alle"         &&<SchuelerListe titel="Alle Schüler" liste={schuelerList} onOpenSchueler={openSchueler} onStatusAendern={onStatusAendern} onLoescheSchueler={onLoescheSchueler}/>}
      {view==="aktiv"        &&<SchuelerListe titel="Aktive Schüler" liste={aktiveSchueler} onOpenSchueler={openSchueler} onStatusAendern={onStatusAendern} onLoescheSchueler={onLoescheSchueler}/>}
      {view==="lernbereiche" &&<LernbereicheView material={material} onOpenLernmaterial={openLernmaterial}/>}
      {view==="neuer"        &&<NeuerSchueler onBack={()=>setView("home")} onSaved={neuerSchueler}/>}
      {view==="diagramm"     &&live&&<DiagrammView schueler={live} schuelerList={schuelerList} setSchuelerList={setSchuelerList} onToggleItem={key=>onToggleItem(live.id,key)} onStatusAendern={onStatusAendern} onOpenLernmaterial={openLernmaterial} material={material} isLehrer/>}
      {view==="lernmaterial" &&selItem&&<LernmaterialView itemKey={selItem} material={material} setMaterial={setMaterial} isLehrer/>}
      {view==="ueber"        &&<UeberView/>}
    </div>
  );
}

function LehrerHome({schuelerList,aktiveSchueler,archivSchueler,dashTab,setDashTab,setView,onOpenSchueler,onStatusAendern,onLoescheSchueler,onNeuerSchueler}) {
  return (
    <div style={{maxWidth:680,margin:"0 auto",padding:"24px 16px"}}>
      <div style={{marginBottom:24}}>
        <div style={{fontSize:26,fontWeight:900,marginBottom:4}}>Willkommen zurück! 👋</div>
        <div style={{color:C.muted,fontSize:15}}>Hier ist dein Lehrer-Dashboard.</div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:20}}>
        <div onClick={()=>setView("alle")} style={{...statCard,cursor:"pointer"}} onMouseEnter={e=>e.currentTarget.style.borderColor=C.blue} onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
          <div style={{fontSize:22,marginBottom:6}}>👥</div>
          <div style={{fontSize:28,fontWeight:900,color:C.blue}}>{schuelerList.length}</div>
          <div style={{fontSize:11,color:C.muted,marginTop:3}}>Schüler gesamt</div>
          <div style={{fontSize:10,color:C.blue,marginTop:6,fontWeight:700}}>Alle ansehen →</div>
        </div>
        <div onClick={()=>setView("aktiv")} style={{...statCard,cursor:"pointer"}} onMouseEnter={e=>e.currentTarget.style.borderColor=C.green} onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
          <div style={{fontSize:22,marginBottom:6}}>🎯</div>
          <div style={{fontSize:28,fontWeight:900,color:C.green}}>{aktiveSchueler.length}</div>
          <div style={{fontSize:11,color:C.muted,marginTop:3}}>Aktive Schüler</div>
          <div style={{fontSize:10,color:C.green,marginTop:6,fontWeight:700}}>Liste ansehen →</div>
        </div>
        <div onClick={()=>setView("lernbereiche")} style={{...statCard,cursor:"pointer"}} onMouseEnter={e=>e.currentTarget.style.borderColor=C.orange} onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
          <div style={{fontSize:22,marginBottom:6}}>📚</div>
          <div style={{fontSize:28,fontWeight:900,color:C.orange}}>{AUSBILDUNG.length}</div>
          <div style={{fontSize:11,color:C.muted,marginTop:3}}>Lernbereiche</div>
          <div style={{fontSize:10,color:C.orange,marginTop:6,fontWeight:700}}>Material →</div>
        </div>
      </div>

      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
        <div style={{display:"flex",gap:6}}>
          <button onClick={()=>setDashTab("aktiv")} style={{background:dashTab==="aktiv"?C.green:C.surface,color:dashTab==="aktiv"?"#fff":C.muted,border:`1px solid ${dashTab==="aktiv"?C.green:C.border}`,borderRadius:8,padding:"8px 14px",cursor:"pointer",fontWeight:600,fontSize:13}}>🟢 Aktiv ({aktiveSchueler.length})</button>
          <button onClick={()=>setDashTab("archiv")} style={{background:dashTab==="archiv"?"#4b5563":C.surface,color:dashTab==="archiv"?"#fff":C.muted,border:`1px solid ${dashTab==="archiv"?"#4b5563":C.border}`,borderRadius:8,padding:"8px 14px",cursor:"pointer",fontWeight:600,fontSize:13}}>📦 Archiv ({archivSchueler.length})</button>
        </div>
        {dashTab==="aktiv"&&<button onClick={()=>setView("neuer")} style={{background:C.green,color:"#fff",border:"none",borderRadius:10,padding:"9px 16px",fontWeight:700,fontSize:13,cursor:"pointer"}}>+ Neuer Schüler</button>}
      </div>

      {dashTab==="aktiv"&&<div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:20}}>
        {aktiveSchueler.map(s=><SchuelerKarte key={s.id} schueler={s} onClick={()=>onOpenSchueler(s)} onStatusAendern={onStatusAendern} onLoeschen={onLoescheSchueler} isArchiv={false}/>)}
        {aktiveSchueler.length===0&&<div style={{background:C.card,borderRadius:14,padding:32,border:`1px solid ${C.border}`,textAlign:"center",color:C.muted}}>
          <div style={{fontSize:40,marginBottom:12}}>👥</div>
          <div style={{fontWeight:700,marginBottom:12}}>Keine aktiven Schüler</div>
          <button onClick={()=>setView("neuer")} style={pBtn}>+ Schüler anlegen</button>
        </div>}
      </div>}

      {dashTab==="archiv"&&<div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:20}}>
        {archivSchueler.map(s=><SchuelerKarte key={s.id} schueler={s} onClick={()=>onOpenSchueler(s)} onStatusAendern={onStatusAendern} onLoeschen={onLoescheSchueler} isArchiv={true}/>)}
        {archivSchueler.length===0&&<div style={{background:C.card,borderRadius:14,padding:32,border:`1px solid ${C.border}`,textAlign:"center",color:C.muted}}>
          <div style={{fontSize:40,marginBottom:12}}>📦</div><div>Noch keine archivierten Schüler.</div>
        </div>}
      </div>}

      {/* Prüfungsreife Coming Soon */}
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:16,padding:"18px 20px",marginBottom:12,opacity:0.7}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <span style={{fontSize:28}}>🏆</span>
          <div style={{flex:1}}>
            <div style={{fontWeight:700,fontSize:15}}>Prüfungsreife</div>
            <div style={{color:C.muted,fontSize:13}}>Automatische Auswertung der Ausbildungsreife</div>
          </div>
          <span style={{background:"rgba(139,92,246,0.2)",color:"#8b5cf6",borderRadius:20,padding:"3px 10px",fontSize:11,fontWeight:700,flexShrink:0}}>Coming Soon</span>
        </div>
      </div>

      {/* Theorie Lektionen Coming Soon */}
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:16,padding:"18px 20px",marginBottom:12,opacity:0.7}}>
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:10}}>
          <span style={{fontSize:28}}>📖</span>
          <div style={{flex:1}}>
            <div style={{fontWeight:700,fontSize:15}}>Theorie Lektionen</div>
            <div style={{color:C.muted,fontSize:13}}>14 Lektionen für die Theorieprüfung</div>
          </div>
          <span style={{background:"rgba(139,92,246,0.2)",color:"#8b5cf6",borderRadius:20,padding:"3px 10px",fontSize:11,fontWeight:700,flexShrink:0}}>Coming Soon</span>
        </div>
        <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
          {[1,2,3,4,5,6,7,8,9,10,11,12,13,14].map(n=>(
            <div key={n} style={{width:36,height:36,borderRadius:8,background:C.surface,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:700,color:C.muted}}>{n}</div>
          ))}
        </div>
      </div>

      {/* Fahrlehrer */}
      <div onClick={()=>setView("ueber")} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:"16px 18px",cursor:"pointer",display:"flex",alignItems:"center",gap:14,marginBottom:12,transition:"border-color .2s"}}
        onMouseEnter={e=>e.currentTarget.style.borderColor=C.orange} onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
        <div style={{width:48,height:48,borderRadius:"50%",background:`linear-gradient(135deg,${C.orange},#d97706)`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>👨‍🏫</div>
        <div style={{flex:1}}><div style={{fontWeight:700,fontSize:15}}>Dein Fahrlehrer</div><div style={{color:C.muted,fontSize:13}}>Infos & Kontakt</div></div>
        <span style={{color:C.muted,fontSize:22}}>›</span>
      </div>

      {/* Social Media & Kontakte */}
      <div style={{fontWeight:700,fontSize:15,marginBottom:10,color:C.muted}}>Social Media & Kontakt</div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
        {[
          {icon:"📸",label:"Instagram",handle:"@fahrschulpro",bg:"linear-gradient(135deg,#833ab4,#fd1d1d,#fcb045)"},
          {icon:"🎵",label:"TikTok",handle:"@fahrschulpro",bg:"#010101",border:`1px solid #333`},
          {icon:"▶️",label:"YouTube",handle:"Fahrschul Videos",bg:"#ff0000"},
          {icon:"💬",label:"WhatsApp",handle:"Direkt schreiben",bg:"#25d366"},
        ].map((s,i)=>(
          <a key={i} href="#" style={{background:s.bg,border:s.border||"none",borderRadius:14,padding:"16px 14px",textDecoration:"none",color:"#fff",display:"flex",flexDirection:"column",gap:6}}>
            <div style={{fontSize:26}}>{s.icon}</div>
            <div style={{fontWeight:800,fontSize:14}}>{s.label}</div>
            <div style={{fontSize:11,opacity:0.75}}>{s.handle}</div>
          </a>
        ))}
      </div>
    </div>
  );
}

function SchuelerListe({titel,liste,onOpenSchueler,onStatusAendern,onLoescheSchueler}) {
  return (
    <div style={{maxWidth:680,margin:"0 auto",padding:"24px 16px"}}>
      <div style={{fontWeight:900,fontSize:22,marginBottom:20}}>{titel} ({liste.length})</div>
      {liste.length===0&&<div style={{textAlign:"center",color:C.muted,padding:40}}>Keine Schüler gefunden.</div>}
      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        {liste.map(s=><SchuelerKarte key={s.id} schueler={s} onClick={()=>onOpenSchueler(s)} onStatusAendern={onStatusAendern} onLoeschen={onLoescheSchueler} isArchiv={["archiviert","abgeschlossen"].includes(s.status||"aktiv")}/>)}
      </div>
    </div>
  );
}

function LernbereicheView({material,onOpenLernmaterial}) {
  return (
    <div style={{maxWidth:680,margin:"0 auto",padding:"24px 16px"}}>
      <div style={{fontWeight:900,fontSize:22,marginBottom:4}}>📚 Lernbereiche</div>
      <div style={{color:"#8fa3b8",fontSize:14,marginBottom:20}}>Übersicht aller Ausbildungspunkte. Klicke auf 📚 um Material zu öffnen.</div>
      <div style={{display:"flex",flexDirection:"column",gap:12}}>
        {AUSBILDUNG.map(s=>(
          <div key={s.id} style={{background:"#1e2e42",borderRadius:14,padding:"18px 20px",border:"1px solid #2a3f5a",borderLeft:`4px solid ${s.color}`}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
              <span style={{fontSize:24}}>{s.icon}</span>
              <div style={{flex:1}}>
                <div style={{fontWeight:800,fontSize:16,color:s.color}}>{s.label}</div>
                <div style={{fontSize:12,color:"#8fa3b8"}}>{s.gruppen.flatMap(g=>g.items).length} Lernpunkte</div>
              </div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {s.gruppen.map(g=>{
                const matKey=`${s.id}::${g.name}`;
                const hatMat=material&&material[matKey]&&(material[matKey].videoUrl||material[matKey].fotos?.length>0||material[matKey].quiz?.length>0);
                return (
                  <div key={g.name} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 12px",background:"#1a2638",borderRadius:8,border:`1px solid ${hatMat?"#06b6d4"+"33":"#2a3f5a"}`}}>
                    <div>
                      <div style={{fontSize:13,fontWeight:600,color:"#e8f0f8"}}>{g.name}</div>
                      <div style={{fontSize:11,color:"#8fa3b8",marginTop:2}}>{g.items.length} Punkte</div>
                    </div>
                    <button onClick={()=>onOpenLernmaterial(matKey)}
                      style={{fontSize:11,background:hatMat?"rgba(6,182,212,0.2)":"rgba(255,255,255,0.06)",color:hatMat?"#06b6d4":"#8fa3b8",border:`1px solid ${hatMat?"#06b6d4"+"44":"#2a3f5a"}`,borderRadius:6,padding:"5px 12px",cursor:"pointer",fontWeight:700,whiteSpace:"nowrap"}}>
                      {hatMat?"📚 Material":"+ Material"}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SchuelerKarte({schueler,onClick,onStatusAendern,onLoeschen,isArchiv}) {
  const [confirmDelete,setConfirmDelete]=useState(false);
  const beh=Object.values(schueler.themen||{}).filter(v=>v===2).length;
  const pct=Math.round((beh/ALL_ITEMS.length)*100);
  const status=schueler.status||"aktiv";
  const st=SCHUELER_STATUS[status]||SCHUELER_STATUS.aktiv;

  if(confirmDelete) return (
    <div style={{background:C.card,border:`2px solid ${C.accent}`,borderRadius:14,padding:"20px 18px"}}>
      <div style={{fontSize:32,textAlign:"center",marginBottom:10}}>⚠️</div>
      <div style={{fontWeight:800,fontSize:16,textAlign:"center",marginBottom:6}}>Schüler löschen?</div>
      <div style={{color:C.muted,fontSize:14,textAlign:"center",marginBottom:16}}>
        <strong style={{color:C.text}}>{schueler.name}</strong> wird unwiderruflich gelöscht – inklusive aller Daten und Fortschritte.
      </div>
      <div style={{display:"flex",gap:10}}>
        <button onClick={()=>onLoeschen(schueler.id)} style={{flex:1,background:C.accent,color:"#fff",border:"none",borderRadius:8,padding:"11px",fontWeight:700,fontSize:14,cursor:"pointer"}}>
          🗑 Ja, löschen
        </button>
        <button onClick={()=>setConfirmDelete(false)} style={{flex:1,background:C.surface,color:C.muted,border:`1px solid ${C.border}`,borderRadius:8,padding:"11px",fontWeight:700,fontSize:14,cursor:"pointer"}}>
          Abbrechen
        </button>
      </div>
    </div>
  );

  return (
    <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:"16px 18px",transition:"border-color .2s"}}
      onMouseEnter={e=>e.currentTarget.style.borderColor=isArchiv?C.muted:C.accent}
      onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
      <div style={{display:"flex",gap:14,alignItems:"center",cursor:"pointer",marginBottom:12}} onClick={onClick}>
        <div style={{position:"relative",flexShrink:0}}>
          <ProgressRing pct={pct} size={52} stroke={5}/>
          <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:900}}>{pct}%</div>
        </div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4,flexWrap:"wrap"}}>
            <div style={{fontWeight:800,fontSize:16}}>{schueler.name}</div>
            <span style={{fontSize:10,background:st.bg,color:st.color,borderRadius:5,padding:"2px 7px",fontWeight:700}}>{st.icon} {st.label}</span>
          </div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            {(schueler.info?.klassen||[]).map(k=><span key={k} style={{fontSize:11,background:"rgba(58,134,255,0.15)",color:C.blue,borderRadius:5,padding:"2px 7px",fontWeight:700}}>Kl. {k}</span>)}
          </div>
        </div>
        <span style={{color:C.muted,fontSize:22,flexShrink:0}}>›</span>
      </div>
      <div style={{paddingTop:10,borderTop:`1px solid ${C.border}`,display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
        {!isArchiv&&<>
          {status!=="aktiv"&&<button onClick={()=>onStatusAendern(schueler.id,"aktiv")} style={sBtn(C.green)}>🟢 Aktiv</button>}
          <button onClick={()=>onStatusAendern(schueler.id,"abgeschlossen")} style={sBtn(C.purple)}>✅ Abgeschlossen</button>
          <button onClick={()=>onStatusAendern(schueler.id,"archiviert")} style={sBtn(C.muted)}>📦 Archivieren</button>
        </>}
        {isArchiv&&<>
          <button onClick={()=>onStatusAendern(schueler.id,"aktiv")} style={sBtn(C.green)}>🔄 Reaktivieren</button>
          <span style={{fontSize:11,color:C.muted,alignSelf:"center"}}>{status==="abgeschlossen"?"✅ Abgeschlossen":"📦 Archiviert"}</span>
        </>}
        {/* Löschen Button – immer sichtbar */}
        <button onClick={()=>setConfirmDelete(true)}
          style={{marginLeft:"auto",fontSize:11,background:"rgba(230,57,70,0.1)",color:C.accent,border:`1px solid ${C.accent}44`,borderRadius:6,padding:"4px 10px",cursor:"pointer",fontWeight:700}}>
          🗑 Löschen
        </button>
      </div>
    </div>
  );
}

const sBtn = color => ({fontSize:11,background:`${color}22`,color,border:`1px solid ${color}44`,borderRadius:6,padding:"4px 10px",cursor:"pointer",fontWeight:700});

function NeuerSchueler({onBack,onSaved}) {
  const [form,setForm]=useState({name:"",pin:""});
  const [err,setErr]=useState("");
  const [success,setSuccess]=useState(null);
  const speichern=()=>{
    if(!form.name.trim()){setErr("Bitte Namen eingeben.");return;}
    if(form.pin.length<4){setErr("PIN mind. 4 Stellen.");return;}
    onSaved(form.name.trim(),form.pin);
    setSuccess({name:form.name.trim(),pin:form.pin});
  };
  if(success) return (
    <div style={{maxWidth:480,margin:"0 auto",padding:"48px 16px",textAlign:"center"}}>
      <div style={{fontSize:64,marginBottom:16}}>🎉</div>
      <div style={{fontWeight:900,fontSize:24,marginBottom:8}}>Schüler angelegt!</div>
      <div style={{background:C.card,borderRadius:12,padding:20,border:`1px solid ${C.border}`,marginBottom:24,textAlign:"left"}}>
        <div style={{fontSize:13,color:C.muted,marginBottom:10,fontWeight:600}}>🔑 Login-Daten:</div>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}><span style={{color:C.muted}}>Name:</span><span style={{fontWeight:800}}>{success.name}</span></div>
        <div style={{display:"flex",justifyContent:"space-between"}}><span style={{color:C.muted}}>PIN:</span><span style={{fontWeight:800,fontSize:20,letterSpacing:4,color:C.blue}}>{success.pin}</span></div>
      </div>
      <div style={{display:"flex",gap:10,justifyContent:"center"}}>
        <button onClick={()=>{setForm({name:"",pin:""});setSuccess(null);setErr("");}} style={{...pBtn,background:C.green}}>+ Weiterer Schüler</button>
        <button onClick={onBack} style={gBtn}>← Dashboard</button>
      </div>
    </div>
  );
  return (
    <div style={{maxWidth:480,margin:"0 auto",padding:"24px 16px"}}>
      <div style={{fontWeight:900,fontSize:22,marginBottom:6}}>Neuen Schüler anlegen</div>
      <div style={{color:C.muted,fontSize:14,marginBottom:24}}>Der Schüler kann sich mit Name & PIN anmelden.</div>
      <div style={{background:C.card,borderRadius:16,padding:24,border:`1px solid ${C.border}`}}>
        <div style={{marginBottom:16}}><label style={lbl}>Vor- und Nachname *</label>
          <input style={inp} value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="z.B. Jonas Weber"/>
        </div>
        <div style={{marginBottom:20}}><label style={lbl}>PIN (mind. 4 Stellen) *</label>
          <input style={inp} type="password" maxLength={8} value={form.pin} onChange={e=>setForm({...form,pin:e.target.value.replace(/\D/g,"")})} placeholder="z.B. 4782"/>
          <div style={{fontSize:12,color:C.muted,marginTop:6}}>💡 Teile den PIN persönlich mit dem Schüler.</div>
        </div>
        {err&&<div style={{background:"#fde8ea",color:C.accent,borderRadius:8,padding:"10px 14px",fontSize:13,marginBottom:16}}>{err}</div>}
        <div style={{display:"flex",gap:10}}>
          <button onClick={speichern} style={{...pBtn,flex:1,padding:"12px"}}>✓ Schüler anlegen</button>
          <button onClick={onBack} style={{...gBtn,padding:"12px 18px"}}>Abbrechen</button>
        </div>
      </div>
    </div>
  );
}

// ── DIAGRAMM VIEW ──────────────────────────────────────────────────────
function DiagrammView({schueler,schuelerList,setSchuelerList,onToggleItem,onStatusAendern,onOpenLernmaterial,material,isLehrer}) {
  const [tab,setTab]=useState("diagramm");
  const [selStufe,setSelStufe]=useState(AUSBILDUNG[0].id);
  const [neueNotiz,setNeueNotiz]=useState("");
  const [editInfo,setEditInfo]=useState(false);
  const [infoForm,setInfoForm]=useState(schueler.info||{klassen:[],sehhilfe:"Keine",theorie:false,fahrlehrer:"",notizen:[]});
  const [pinSichtbar,setPinSichtbar]=useState(false);

  const live=schuelerList?schuelerList.find(s=>s.id===schueler.id)||schueler:schueler;
  const pct=Math.round((Object.values(live.themen||{}).filter(v=>v===2).length/ALL_ITEMS.length)*100);
  const stufe=AUSBILDUNG.find(s=>s.id===selStufe)||AUSBILDUNG[0];
  const status=live.status||"aktiv";
  const st=SCHUELER_STATUS[status]||SCHUELER_STATUS.aktiv;

  const addNotiz=()=>{
    if(!neueNotiz.trim()) return;
    const notiz={id:"n"+Date.now(),text:neueNotiz.trim(),datum:new Date().toISOString().split("T")[0]};
    if(setSchuelerList) setSchuelerList(prev=>prev.map(s=>s.id===schueler.id?{...s,info:{...s.info,notizen:[notiz,...(s.info?.notizen||[])]}}:s));
    setNeueNotiz("");
  };
  const deleteNotiz=id=>{
    if(setSchuelerList) setSchuelerList(prev=>prev.map(s=>s.id===schueler.id?{...s,info:{...s.info,notizen:(s.info?.notizen||[]).filter(n=>n.id!==id)}}:s));
  };
  const saveInfo=()=>{
    if(setSchuelerList) setSchuelerList(prev=>prev.map(s=>s.id===schueler.id?{...s,info:{...s.info,...infoForm}}:s));
    setEditInfo(false);
  };
  const toggleKlasse=k=>{
    const cur=infoForm.klassen||[];
    setInfoForm({...infoForm,klassen:cur.includes(k)?cur.filter(x=>x!==k):[...cur,k]});
  };

  return (
    <div style={{maxWidth:680,margin:"0 auto",padding:"24px 16px"}}>
      {/* Header */}
      <div style={{background:C.surface,borderRadius:12,padding:20,marginBottom:16,display:"flex",gap:16,alignItems:"center"}}>
        <div style={{position:"relative",flexShrink:0}}>
          <ProgressRing pct={pct} size={64} stroke={6}/>
          <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:900}}>{pct}%</div>
        </div>
        <div style={{flex:1}}>
          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4,flexWrap:"wrap"}}>
            <div style={{fontWeight:900,fontSize:20}}>{isLehrer?live.name:"Mein Ausbildungsstand"}</div>
            <span style={{fontSize:11,background:st.bg,color:st.color,borderRadius:5,padding:"2px 8px",fontWeight:700}}>{st.icon} {st.label}</span>
          </div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            {(live.info?.klassen||[]).map(k=><span key={k} style={{fontSize:11,background:"rgba(58,134,255,0.2)",color:C.blue,borderRadius:5,padding:"2px 8px",fontWeight:700}}>Kl. {k}</span>)}
            {isLehrer&&<span style={{fontSize:11,background:live.info?.theorie?"rgba(16,185,129,0.2)":"rgba(245,158,11,0.15)",color:live.info?.theorie?C.green:C.orange,borderRadius:5,padding:"2px 8px",fontWeight:700}}>
              {live.info?.theorie?"✅ Theorie":"⏳ Theorie ausstehend"}
            </span>}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{display:"flex",gap:6,marginBottom:16,flexWrap:"wrap"}}>
        {[["diagramm","📊 Diagramm"],["notizen","📝 Notizen"],...(isLehrer?[["akte","👤 Schülerakte"]]:[])].map(([k,l])=>(
          <button key={k} onClick={()=>setTab(k)} style={{background:tab===k?C.accent:C.surface,color:tab===k?"#fff":C.muted,border:`1px solid ${tab===k?C.accent:C.border}`,borderRadius:8,padding:"9px 14px",cursor:"pointer",fontWeight:600,fontSize:13}}>{l}</button>
        ))}
      </div>

      {/* DIAGRAMM */}
      {tab==="diagramm"&&<>
        <div style={{display:"flex",gap:6,marginBottom:14,overflowX:"auto",paddingBottom:4}}>
          {AUSBILDUNG.map(s=>{
            const keys=s.gruppen.flatMap(g=>g.items.map(i=>`${s.id}::${g.name}::${i}`));
            const sBeh=keys.filter(k=>(live.themen||{})[k]===2).length;
            const sPct=Math.round((sBeh/keys.length)*100);
            const active=selStufe===s.id;
            return (
              <button key={s.id} onClick={()=>setSelStufe(s.id)}
                style={{background:active?s.color:"rgba(255,255,255,0.05)",color:active?"#fff":C.muted,border:`1.5px solid ${active?s.color:C.border}`,borderRadius:10,padding:"8px 12px",cursor:"pointer",fontWeight:700,fontSize:11,whiteSpace:"nowrap",flexShrink:0,display:"flex",flexDirection:"column",alignItems:"center",gap:2,minWidth:76}}>
                <span style={{fontSize:18}}>{s.icon}</span>
                <span>{s.label}</span>
                <span style={{fontSize:10,opacity:0.85}}>{sPct}%</span>
              </button>
            );
          })}
        </div>
        <div style={{background:C.card,borderRadius:14,padding:18,border:`2px solid ${stufe.color}44`}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
            <span style={{fontSize:24}}>{stufe.icon}</span>
            <div><div style={{fontWeight:900,fontSize:17,color:stufe.color}}>{stufe.label}</div>
            <div style={{fontSize:12,color:C.muted}}>{stufe.gruppen.flatMap(g=>g.items).length} Lernpunkte</div></div>
          </div>
          <div style={{display:"flex",gap:10,marginBottom:12,padding:"7px 12px",background:"rgba(255,255,255,0.04)",borderRadius:8,alignItems:"center",flexWrap:"wrap"}}>
            <span style={{fontSize:11,color:C.muted}}>{isLehrer?"Klicken:":"Dein Stand:"}</span>
            {[{fill:0,color:"#2a3f5a",label:"Offen"},{fill:0.5,color:"#f59e0b",label:"In Arbeit"},{fill:1,color:"#10b981",label:"Fertig"}].map((s,i)=>(
              <div key={i} style={{display:"flex",alignItems:"center",gap:5}}>
                <div style={{width:26,height:7,background:"#1a2638",borderRadius:99,overflow:"hidden",border:`1px solid ${s.color}66`}}>
                  <div style={{height:"100%",width:`${s.fill*100}%`,background:s.color,borderRadius:99}}/>
                </div>
                <span style={{fontSize:10,color:C.muted}}>{s.label}</span>
              </div>
            ))}
          </div>
          {stufe.gruppen.map(gruppe=>{
            const gKeys=gruppe.items.map(i=>`${stufe.id}::${gruppe.name}::${i}`);
            const gBeh=gKeys.filter(k=>(live.themen||{})[k]===2).length;
            // Material Key ist pro Gruppe
            const gruppeMatKey=`${stufe.id}::${gruppe.name}`;
            const hatGruppeMaterial=material&&material[gruppeMatKey]&&(material[gruppeMatKey].videoUrl||material[gruppeMatKey].fotos?.length>0||material[gruppeMatKey].quiz?.length>0);
            return (
              <div key={gruppe.name} style={{marginBottom:14}}>
                {/* Gruppen Header mit Material Button */}
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                  <div style={{fontWeight:700,fontSize:14}}>{gruppe.name}</div>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <button onClick={()=>onOpenLernmaterial&&onOpenLernmaterial(gruppeMatKey)}
                      style={{fontSize:10,background:hatGruppeMaterial?"rgba(6,182,212,0.2)":"rgba(255,255,255,0.06)",color:hatGruppeMaterial?C.cyan:C.muted,border:`1px solid ${hatGruppeMaterial?C.cyan+"44":C.border}`,borderRadius:6,padding:"3px 10px",cursor:"pointer",fontWeight:700,whiteSpace:"nowrap"}}>
                      {hatGruppeMaterial?"📚 Material":"+ Material"}
                    </button>
                    <span style={{fontSize:11,color:C.muted}}>{gBeh}/{gruppe.items.length}</span>
                  </div>
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:5}}>
                  {gruppe.items.map(item=>{
                    const key=`${stufe.id}::${gruppe.name}::${item}`;
                    const val=(live.themen||{})[key]||0;
                    const stl=getStufe(val);
                    return (
                      <div key={item} style={{display:"flex",alignItems:"center",gap:8,padding:"9px 12px",borderRadius:8,background:stl.bg,border:`1px solid ${val>0?stl.color+"33":C.border}`,transition:"background .2s"}}>
                        <span style={{flex:1,fontSize:13,color:C.text}}>{item}</span>
                        <FillBar value={val} onClick={isLehrer?()=>onToggleItem(key):undefined} readonly={!isLehrer}/>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </>}

      {/* NOTIZEN */}
      {tab==="notizen"&&(
        <div>
          {isLehrer&&(
            <div style={{background:C.card,borderRadius:14,padding:18,border:`1px solid ${C.border}`,marginBottom:16}}>
              <div style={{fontWeight:700,fontSize:15,marginBottom:12}}>📝 Neue Notiz</div>
              <textarea value={neueNotiz} onChange={e=>setNeueNotiz(e.target.value)} placeholder="Notiz für den Schüler..." style={{...inp,minHeight:90,resize:"vertical",marginBottom:10}}/>
              <button onClick={addNotiz} style={{...pBtn,width:"100%"}}>Notiz speichern</button>
            </div>
          )}
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            {(live.info?.notizen||[]).length===0&&<div style={{textAlign:"center",color:C.muted,padding:40,background:C.card,borderRadius:14,border:`1px solid ${C.border}`}}>
              <div style={{fontSize:32,marginBottom:10}}>📝</div>Noch keine Notizen.
            </div>}
            {(live.info?.notizen||[]).map(n=>(
              <div key={n.id} style={{background:C.card,borderRadius:12,padding:16,border:`1px solid ${C.border}`,borderLeft:`3px solid ${C.blue}`}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                  <div style={{fontSize:12,color:C.muted,fontWeight:600}}>👨‍🏫 {new Date(n.datum).toLocaleDateString("de-DE",{day:"2-digit",month:"long",year:"numeric"})}</div>
                  {isLehrer&&<button onClick={()=>deleteNotiz(n.id)} style={{background:"none",border:"none",cursor:"pointer",color:C.muted,fontSize:16}}>🗑</button>}
                </div>
                <div style={{fontSize:14,lineHeight:1.6}}>{n.text}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SCHÜLERAKTE */}
      {tab==="akte"&&isLehrer&&(
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div style={{background:C.card,borderRadius:14,padding:20,border:`1px solid ${C.border}`}}>
            <div style={{fontWeight:700,fontSize:15,marginBottom:14}}>🔄 Ausbildungsstatus</div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {Object.entries(SCHUELER_STATUS).map(([key,s])=>(
                <button key={key} onClick={()=>onStatusAendern&&onStatusAendern(schueler.id,key)}
                  style={{padding:"8px 14px",borderRadius:8,border:`2px solid ${status===key?s.color:C.border}`,background:status===key?s.bg:"transparent",cursor:"pointer",fontSize:12,fontWeight:700,color:status===key?s.color:C.muted}}>
                  {s.icon} {s.label}
                </button>
              ))}
            </div>
          </div>
          <div style={{background:C.card,borderRadius:14,padding:20,border:`1px solid ${C.border}`}}>
            <div style={{fontWeight:700,fontSize:15,marginBottom:14}}>🔑 Login-Daten</div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10,padding:"10px 14px",background:C.surface,borderRadius:8}}>
              <span style={{color:C.muted,fontSize:14}}>Name</span><span style={{fontWeight:700,fontSize:15}}>{live.name}</span>
            </div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 14px",background:C.surface,borderRadius:8}}>
              <span style={{color:C.muted,fontSize:14}}>PIN</span>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <span style={{fontWeight:800,fontSize:18,letterSpacing:pinSichtbar?3:2,color:C.blue}}>{pinSichtbar?live.pin:"••••"}</span>
                <button onClick={()=>setPinSichtbar(!pinSichtbar)} style={{background:"rgba(58,134,255,0.15)",color:C.blue,border:"none",borderRadius:6,padding:"4px 10px",fontSize:12,cursor:"pointer",fontWeight:700}}>{pinSichtbar?"Verbergen":"Anzeigen"}</button>
              </div>
            </div>
          </div>
          <div style={{background:C.card,borderRadius:14,padding:20,border:`1px solid ${C.border}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
              <div style={{fontWeight:700,fontSize:15}}>📋 Schüler-Infos</div>
              <button onClick={()=>editInfo?saveInfo():setEditInfo(true)} style={{background:editInfo?C.green:C.surface,color:editInfo?"#fff":C.muted,border:`1px solid ${editInfo?C.green:C.border}`,borderRadius:8,padding:"6px 14px",fontSize:12,cursor:"pointer",fontWeight:700}}>{editInfo?"✓ Speichern":"✏️ Bearbeiten"}</button>
            </div>
            {editInfo?(
              <div style={{display:"flex",flexDirection:"column",gap:14}}>
                <div><label style={lbl}>Fahrerlaubnisklassen</label>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                    {KLASSEN.map(k=>{const sel=(infoForm.klassen||[]).includes(k);return(
                      <div key={k} onClick={()=>toggleKlasse(k)} style={{padding:"6px 12px",borderRadius:8,border:`2px solid ${sel?C.blue:C.border}`,background:sel?"rgba(58,134,255,0.15)":"transparent",cursor:"pointer",fontSize:13,fontWeight:700,color:sel?C.blue:C.muted}}>{k}</div>
                    );})}
                  </div>
                </div>
                <div><label style={lbl}>Sehhilfe</label>
                  <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                    {["Keine","Brille","Kontaktlinsen","Beide"].map(opt=>(
                      <div key={opt} onClick={()=>setInfoForm({...infoForm,sehhilfe:opt})} style={{flex:1,minWidth:80,padding:"8px",borderRadius:8,border:`2px solid ${infoForm.sehhilfe===opt?C.blue:C.border}`,background:infoForm.sehhilfe===opt?"rgba(58,134,255,0.15)":"transparent",cursor:"pointer",fontSize:12,fontWeight:600,color:infoForm.sehhilfe===opt?C.blue:C.muted,textAlign:"center"}}>{opt}</div>
                    ))}
                  </div>
                </div>
                <div><label style={lbl}>Theorie</label>
                  <div style={{display:"flex",gap:8}}>
                    {[{label:"⏳ Noch nicht bestanden",val:false},{label:"✅ Bestanden",val:true}].map(opt=>(
                      <div key={String(opt.val)} onClick={()=>setInfoForm({...infoForm,theorie:opt.val})} style={{flex:1,padding:"10px",borderRadius:8,border:`2px solid ${infoForm.theorie===opt.val?(opt.val?C.green:C.accent):C.border}`,background:infoForm.theorie===opt.val?(opt.val?"rgba(16,185,129,0.15)":"rgba(230,57,70,0.1)"):"transparent",cursor:"pointer",fontSize:12,fontWeight:700,color:infoForm.theorie===opt.val?(opt.val?C.green:C.accent):C.muted,textAlign:"center"}}>{opt.label}</div>
                    ))}
                  </div>
                </div>
                <div><label style={lbl}>Zuständiger Fahrlehrer</label>
                  <input style={inp} value={infoForm.fahrlehrer||""} onChange={e=>setInfoForm({...infoForm,fahrlehrer:e.target.value})} placeholder="Name des Fahrlehrers"/>
                </div>
                <button onClick={()=>setEditInfo(false)} style={{...gBtn,width:"100%",textAlign:"center"}}>Abbrechen</button>
              </div>
            ):(
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                <div style={{padding:"10px 14px",background:C.surface,borderRadius:8}}>
                  <div style={{color:C.muted,fontSize:13,marginBottom:6}}>🚗 Fahrerlaubnisklassen</div>
                  {(live.info?.klassen||[]).length>0
                    ?<div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{live.info.klassen.map(k=><span key={k} style={{background:"rgba(58,134,255,0.2)",color:C.blue,borderRadius:6,padding:"4px 10px",fontSize:13,fontWeight:700}}>Kl. {k}</span>)}</div>
                    :<span style={{fontSize:14,color:C.muted}}>–</span>}
                </div>
                {[{icon:"👁",label:"Sehhilfe",value:live.info?.sehhilfe||"–"},{icon:"👨‍🏫",label:"Fahrlehrer",value:live.info?.fahrlehrer||"–"}].map((row,i)=>(
                  <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 14px",background:C.surface,borderRadius:8}}>
                    <span style={{color:C.muted,fontSize:13}}>{row.icon} {row.label}</span>
                    <span style={{fontWeight:600,fontSize:14}}>{row.value}</span>
                  </div>
                ))}
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 14px",background:C.surface,borderRadius:8}}>
                  <span style={{color:C.muted,fontSize:13}}>📝 Theorie</span>
                  <span style={{fontWeight:700,fontSize:14,color:live.info?.theorie?C.green:C.orange}}>{live.info?.theorie?"✅ Bestanden":"⏳ Noch nicht bestanden"}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// LERNMATERIAL VIEW
// ══════════════════════════════════════════════════════════════════════
function LernmaterialView({itemKey,material,setMaterial,isLehrer}) {
  const parts=itemKey.split("::");
  const themaName=parts[1]||itemKey;

  const [mat,setMat]=useState({videoUrl:"",fotos:[],quiz:[]});
  const [videoInput,setVideoInput]=useState("");
  const [fotoInput,setFotoInput]=useState("");
  const [quizState,setQuizState]=useState(null);
  const [editQuiz,setEditQuiz]=useState(false);
  const [quizForm,setQuizForm]=useState({frage:"",typ:"mc",antworten:["","","",""],richtig:0,erklaerung:""});
  const [saving,setSaving]=useState(false);
  const [loaded,setLoaded]=useState(false);

  // Direkt aus Supabase laden
  useEffect(()=>{
    const laden=async()=>{
      const [matRes,quizRes]=await Promise.all([
        supabase.from("lernmaterial").select("*").eq("item_key",itemKey).single(),
        supabase.from("quiz_fragen").select("*").eq("item_key",itemKey),
      ]);
      const loaded={
        videoUrl:matRes.data?.video_url||"",
        fotos:matRes.data?.fotos||[],
        quiz:(quizRes.data||[]).map(q=>({id:q.id,frage:q.frage,typ:q.typ,antworten:q.antworten||[],richtig:q.richtig,erklaerung:q.erklaerung||""})),
      };
      setMat(loaded);
      setVideoInput(loaded.videoUrl||"");
      setLoaded(true);
    };
    laden();
  },[itemKey]);

  const getEmbed=url=>{
    const m=url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\s]+)/);
    return m?`https://www.youtube.com/embed/${m[1]}`:url;
  };

  // Speichert lokal UND in Supabase
  const saveMaterial=async(updates)=>{
    const merged={...mat,...updates};
    // Lokal updaten
    setMat(merged);
    if(setMaterial) setMaterial(prev=>({...prev,[itemKey]:merged}));
    // In Supabase speichern
    setSaving(true);
    const {error:matError}=await supabase.from("lernmaterial").upsert({
      item_key:itemKey,
      video_url:merged.videoUrl||"",
      fotos:merged.fotos||[],
      aktualisiert_am:new Date().toISOString(),
    },{onConflict:"item_key"});
    if(matError) console.error("Lernmaterial Fehler:",matError);
    // Quiz separat
    if(updates.quiz!==undefined){
      await supabase.from("quiz_fragen").delete().eq("item_key",itemKey);
      if(merged.quiz?.length>0){
        const {error:quizError}=await supabase.from("quiz_fragen").insert(
          merged.quiz.map(q=>({item_key:itemKey,frage:q.frage,typ:q.typ,antworten:q.antworten||[],richtig:typeof q.richtig==="boolean"?(q.richtig?1:0):q.richtig,erklaerung:q.erklaerung||""}))
        );
        if(quizError) console.error("Quiz Fehler:",quizError);
      }
    }
    setSaving(false);
  };

  const saveVideo=async()=>{
    await saveMaterial({videoUrl:getEmbed(videoInput)});
  };

  const addFoto=async()=>{
    if(!fotoInput.trim()) return;
    const neu=[...(mat.fotos||[]),fotoInput.trim()];
    await saveMaterial({fotos:neu});
    setFotoInput("");
  };

  const deleteFoto=async(idx)=>{
    const neu=(mat.fotos||[]).filter((_,i)=>i!==idx);
    await saveMaterial({fotos:neu});
  };

  const addQuizFrage=async()=>{
    if(!quizForm.frage.trim()) return;
    const q={id:"q"+Date.now(),...quizForm,antworten:quizForm.antworten.filter(a=>a.trim())};
    await saveMaterial({quiz:[...(mat.quiz||[]),q]});
    setQuizForm({frage:"",typ:"mc",antworten:["","","",""],richtig:0,erklaerung:""});
    setEditQuiz(false);
  };

  const deleteQuizFrage=async(id)=>{
    await saveMaterial({quiz:(mat.quiz||[]).filter(q=>q.id!==id)});
  };

  if(quizState) return <QuizView quiz={mat.quiz} state={quizState} setState={setQuizState} onBack={()=>setQuizState(null)} themaName={themaName}/>;

  return (
    <div style={{maxWidth:680,margin:"0 auto",padding:"24px 16px"}}>
      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:20}}>
        <span style={{fontSize:28}}>📚</span>
        <div style={{flex:1}}>
          <div style={{fontWeight:900,fontSize:20}}>{themaName}</div>
          <div style={{fontSize:12,color:C.muted}}>Lernmaterial</div>
        </div>
        {saving&&<span style={{fontSize:12,color:C.orange,fontWeight:700}}>⏳ Speichern...</span>}
        {!saving&&isLehrer&&<span style={{fontSize:12,color:C.green,fontWeight:700}}>✓ Gespeichert</span>}
      </div>

      {/* VIDEO */}
      <div style={{background:C.card,borderRadius:14,padding:20,border:`1px solid ${C.border}`,marginBottom:14}}>
        <div style={{fontWeight:700,fontSize:15,marginBottom:14}}>📹 Video</div>
        {isLehrer&&(
          <div style={{marginBottom:14,display:"flex",gap:8}}>
            <input style={{...inp,flex:1}} placeholder="YouTube Link einfügen..." value={videoInput} onChange={e=>setVideoInput(e.target.value)}/>
            <button onClick={saveVideo} style={{...pBtn,padding:"10px 16px",background:C.blue,whiteSpace:"nowrap"}}>Speichern</button>
          </div>
        )}
        {mat.videoUrl
          ?<div style={{position:"relative",paddingBottom:"56.25%",height:0,borderRadius:10,overflow:"hidden"}}>
            <iframe src={mat.videoUrl} style={{position:"absolute",top:0,left:0,width:"100%",height:"100%",border:"none"}} allowFullScreen title="Video"/>
          </div>
          :<div style={{textAlign:"center",padding:32,color:C.muted,background:C.surface,borderRadius:10,fontSize:14}}>
            {isLehrer?"Noch kein Video – YouTube Link oben einfügen.":"Noch kein Video hinterlegt."}
          </div>
        }
      </div>

      {/* FOTOS */}
      <div style={{background:C.card,borderRadius:14,padding:20,border:`1px solid ${C.border}`,marginBottom:14}}>
        <div style={{fontWeight:700,fontSize:15,marginBottom:14}}>🖼 Fotos</div>
        {isLehrer&&(
          <div style={{marginBottom:14,display:"flex",flexDirection:"column",gap:8}}>
            {/* Foto direkt hochladen */}
            <label style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,background:`linear-gradient(135deg,${C.green},#059669)`,color:"#fff",borderRadius:8,padding:"11px",cursor:"pointer",fontWeight:700,fontSize:14}}>
              📷 Foto vom Handy hochladen
              <input type="file" accept="image/*" style={{display:"none"}} onChange={async e=>{
                const fotoFile=e.target.files[0];
                if(!fotoFile) return;
                setSaving(true);
                const fotoName=`foto_${Date.now()}.${fotoFile.name.split(".").pop()||"jpg"}`;
                const {error:fotoError}=await supabase.storage.from("Lernmaterial").upload(fotoName,fotoFile,{upsert:true,contentType:fotoFile.type});
                if(fotoError){
                  alert("Upload Fehler: "+fotoError.message);
                } else {
                  const {data:fotoUrl}=supabase.storage.from("Lernmaterial").getPublicUrl(fotoName);
                  await saveMaterial({fotos:[...(mat.fotos||[]),fotoUrl.publicUrl]});
                }
                setSaving(false);
              }}/>
            </label>
            {/* Oder URL */}
            <div style={{display:"flex",gap:8,alignItems:"center"}}>
              <div style={{flex:1,height:1,background:C.border}}/>
              <span style={{fontSize:11,color:C.muted,whiteSpace:"nowrap"}}>oder URL eingeben</span>
              <div style={{flex:1,height:1,background:C.border}}/>
            </div>
            <div style={{display:"flex",gap:8}}>
              <input style={{...inp,flex:1}} placeholder="https://...jpg" value={fotoInput} onChange={e=>setFotoInput(e.target.value)}/>
              <button onClick={addFoto} style={{...pBtn,padding:"10px 16px",background:C.surface,border:`1px solid ${C.border}`,color:C.muted,whiteSpace:"nowrap"}}>+ URL</button>
            </div>
          </div>
        )}
        {(mat.fotos||[]).length===0
          ?<div style={{textAlign:"center",padding:28,color:C.muted,background:C.surface,borderRadius:10,fontSize:14}}>
            {isLehrer?"Noch keine Fotos – URL oben einfügen.":"Noch keine Fotos hinterlegt."}
          </div>
          :<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:10}}>
            {(mat.fotos||[]).map((url,i)=>(
              <div key={i} style={{position:"relative",borderRadius:10,overflow:"hidden",border:`1px solid ${C.border}`}}>
                <img src={url} alt={`Foto ${i+1}`} style={{width:"100%",height:160,objectFit:"cover",display:"block"}}
                  onError={e=>{e.target.style.display="none";e.target.nextSibling.style.display="flex";}}/>
                <div style={{display:"none",height:160,background:C.surface,alignItems:"center",justifyContent:"center",color:C.muted,fontSize:12}}>Bild nicht ladbar</div>
                {isLehrer&&<button onClick={()=>deleteFoto(i)} style={{position:"absolute",top:6,right:6,background:"rgba(0,0,0,0.6)",border:"none",borderRadius:6,color:"#fff",padding:"4px 8px",cursor:"pointer",fontSize:14}}>🗑</button>}
              </div>
            ))}
          </div>
        }
      </div>

      {/* QUIZ */}
      <div style={{background:C.card,borderRadius:14,padding:20,border:`1px solid ${C.border}`}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <div style={{fontWeight:700,fontSize:15}}>❓ Quiz ({(mat.quiz||[]).length} Fragen)</div>
          <div style={{display:"flex",gap:8}}>
            {(mat.quiz||[]).length>0&&<button onClick={()=>setQuizState({index:0,answers:{},submitted:false,score:0})} style={{...pBtn,background:C.green,padding:"8px 14px",fontSize:12}}>▶ Quiz starten</button>}
            {isLehrer&&<button onClick={()=>setEditQuiz(!editQuiz)} style={{...gBtn,fontSize:12,padding:"8px 12px"}}>{editQuiz?"Abbrechen":"+ Frage"}</button>}
          </div>
        </div>

        {/* Neue Frage */}
        {editQuiz&&isLehrer&&(
          <div style={{background:C.surface,borderRadius:10,padding:16,marginBottom:14,border:`1px solid ${C.border}`}}>
            <div style={{marginBottom:10}}>
              <label style={lbl}>Fragetyp</label>
              <div style={{display:"flex",gap:8}}>
                {[{val:"mc",label:"Multiple Choice"},{val:"wf",label:"Wahr/Falsch"}].map(t=>(
                  <div key={t.val} onClick={()=>setQuizForm({...quizForm,typ:t.val})}
                    style={{flex:1,padding:"8px",borderRadius:8,border:`2px solid ${quizForm.typ===t.val?C.blue:C.border}`,background:quizForm.typ===t.val?"rgba(58,134,255,0.15)":"transparent",cursor:"pointer",fontSize:12,fontWeight:600,color:quizForm.typ===t.val?C.blue:C.muted,textAlign:"center"}}>
                    {t.label}
                  </div>
                ))}
              </div>
            </div>
            <div style={{marginBottom:10}}>
              <label style={lbl}>Frage *</label>
              <input style={inp} value={quizForm.frage} onChange={e=>setQuizForm({...quizForm,frage:e.target.value})} placeholder="Deine Frage..."/>
            </div>
            {quizForm.typ==="mc"&&<>
              <div style={{marginBottom:10}}>
                <label style={lbl}>Antwortmöglichkeiten</label>
                {quizForm.antworten.map((a,i)=>(
                  <input key={i} style={{...inp,marginBottom:6}} placeholder={`Antwort ${i+1}`} value={a} onChange={e=>{const neu=[...quizForm.antworten];neu[i]=e.target.value;setQuizForm({...quizForm,antworten:neu});}}/>
                ))}
              </div>
              <div style={{marginBottom:10}}>
                <label style={lbl}>Richtige Antwort</label>
                <select style={inp} value={quizForm.richtig} onChange={e=>setQuizForm({...quizForm,richtig:parseInt(e.target.value)})}>
                  {quizForm.antworten.map((a,i)=><option key={i} value={i}>{i+1}. {a||`Antwort ${i+1}`}</option>)}
                </select>
              </div>
            </>}
            {quizForm.typ==="wf"&&(
              <div style={{marginBottom:10}}>
                <label style={lbl}>Richtige Antwort</label>
                <div style={{display:"flex",gap:8}}>
                  {[{val:true,label:"✓ Wahr"},{val:false,label:"✗ Falsch"}].map(opt=>(
                    <div key={String(opt.val)} onClick={()=>setQuizForm({...quizForm,richtig:opt.val})}
                      style={{flex:1,padding:"10px",borderRadius:8,border:`2px solid ${quizForm.richtig===opt.val?C.green:C.border}`,background:quizForm.richtig===opt.val?"rgba(16,185,129,0.15)":"transparent",cursor:"pointer",fontSize:13,fontWeight:700,color:quizForm.richtig===opt.val?C.green:C.muted,textAlign:"center"}}>
                      {opt.label}
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div style={{marginBottom:14}}>
              <label style={lbl}>Erklärung (optional)</label>
              <input style={inp} value={quizForm.erklaerung} onChange={e=>setQuizForm({...quizForm,erklaerung:e.target.value})} placeholder="Erklärung der richtigen Antwort..."/>
            </div>
            <button onClick={addQuizFrage} style={{...pBtn,width:"100%"}}>Frage speichern</button>
          </div>
        )}

        {/* Fragen Liste */}
        {(mat.quiz||[]).length===0&&!editQuiz&&(
          <div style={{textAlign:"center",padding:28,color:C.muted,background:C.surface,borderRadius:10,fontSize:14}}>
            {isLehrer?"Noch keine Fragen – klicke \"+ Frage\".":"Noch keine Quiz-Fragen hinterlegt."}
          </div>
        )}
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {(mat.quiz||[]).map((q,i)=>(
            <div key={q.id} style={{background:C.surface,borderRadius:8,padding:"11px 14px",display:"flex",alignItems:"center",gap:8,border:`1px solid ${C.border}`}}>
              <span style={{fontSize:11,background:q.typ==="mc"?"rgba(58,134,255,0.2)":"rgba(16,185,129,0.2)",color:q.typ==="mc"?C.blue:C.green,borderRadius:4,padding:"2px 7px",fontWeight:700,flexShrink:0}}>
                {q.typ==="mc"?"MC":"W/F"}
              </span>
              <span style={{fontSize:13,flex:1}}>{q.frage}</span>
              {isLehrer&&<button onClick={()=>deleteQuizFrage(q.id)} style={{background:"none",border:"none",cursor:"pointer",color:C.muted,fontSize:16,flexShrink:0}}>🗑</button>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── QUIZ VIEW ──────────────────────────────────────────────────────────
function QuizView({quiz,state,setState,onBack,themaName}) {
  const {index,answers,submitted,score}=state;
  const submit=()=>{
    let sc=0;
    quiz.forEach(q=>{
      const ans=answers[q.id];
      if(q.typ==="mc"&&ans===q.richtig) sc++;
      else if(q.typ==="wf"&&ans===q.richtig) sc++;
    });
    setState({...state,submitted:true,score:sc});
  };

  if(submitted){
    const pct=Math.round((score/quiz.length)*100);
    return (
      <div style={{maxWidth:680,margin:"0 auto",padding:"24px 16px"}}>
        <div style={{textAlign:"center",padding:"32px 0 24px"}}>
          <div style={{fontSize:52}}>{pct>=70?"🎉":"📚"}</div>
          <h2 style={{margin:"10px 0 4px"}}>{pct>=70?"Super gemacht!":"Weiter üben!"}</h2>
          <div style={{fontSize:40,fontWeight:900,color:pct>=70?C.green:C.accent}}>{pct}%</div>
          <div style={{color:C.muted,marginBottom:24}}>{score} von {quiz.length} richtig</div>
        </div>
        {quiz.map((q,i)=>{
          const ans=answers[q.id];
          const ok=q.typ==="mc"?ans===q.richtig:ans===q.richtig;
          return (
            <div key={q.id} style={{background:C.card,borderRadius:12,padding:16,marginBottom:10,border:`1px solid ${C.border}`,borderLeft:`4px solid ${ok?C.green:C.accent}`}}>
              <div style={{fontWeight:700,marginBottom:6}}>#{i+1} {q.frage}</div>
              {q.typ==="mc"&&<div style={{fontSize:13}}>{ok?"✅":"❌"} {q.antworten[ans]||"–"}{!ok&&<span style={{color:C.green}}> · Richtig: {q.antworten[q.richtig]}</span>}</div>}
              {q.typ==="wf"&&<div style={{fontSize:13}}>{ok?"✅":"❌"} {ans===true?"Wahr":ans===false?"Falsch":"–"}{!ok&&<span style={{color:C.green}}> · Richtig: {q.richtig?"Wahr":"Falsch"}</span>}</div>}
              {q.erklaerung&&<div style={{marginTop:6,fontSize:13,color:C.muted,fontStyle:"italic"}}>💡 {q.erklaerung}</div>}
            </div>
          );
        })}
        <button onClick={onBack} style={{...pBtn,width:"100%",marginTop:8}}>← Zurück zum Material</button>
      </div>
    );
  }

  const q=quiz[index];
  return (
    <div style={{maxWidth:680,margin:"0 auto",padding:"24px 16px"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <button onClick={onBack} style={gBtn}>← Abbrechen</button>
        <span style={{color:C.muted,fontSize:14}}>Frage {index+1} / {quiz.length}</span>
      </div>
      <div style={{background:C.border,borderRadius:99,height:6,marginBottom:20}}>
        <div style={{background:C.blue,height:6,borderRadius:99,width:`${((index+1)/quiz.length)*100}%`,transition:"width .3s"}}/>
      </div>
      <div style={{background:C.card,borderRadius:16,padding:20,marginBottom:16,border:`1px solid ${C.border}`}}>
        <div style={{fontSize:18,fontWeight:700,marginBottom:20}}>{q.frage}</div>
        {q.typ==="mc"&&<div style={{display:"flex",flexDirection:"column",gap:10}}>
          {q.antworten.map((a,i)=>(
            <button key={i} onClick={()=>setState({...state,answers:{...answers,[q.id]:i}})}
              style={{background:answers[q.id]===i?C.blue:"rgba(255,255,255,0.05)",color:"#fff",border:`1.5px solid ${answers[q.id]===i?C.blue:C.border}`,borderRadius:8,padding:"12px 16px",cursor:"pointer",textAlign:"left",fontSize:15,fontWeight:answers[q.id]===i?700:400}}>
              {a}
            </button>
          ))}
        </div>}
        {q.typ==="wf"&&<div style={{display:"flex",gap:12}}>
          {[{val:true,label:"✓ Wahr"},{val:false,label:"✗ Falsch"}].map(opt=>(
            <button key={String(opt.val)} onClick={()=>setState({...state,answers:{...answers,[q.id]:opt.val}})}
              style={{flex:1,background:answers[q.id]===opt.val?C.blue:"rgba(255,255,255,0.05)",color:"#fff",border:`1.5px solid ${answers[q.id]===opt.val?C.blue:C.border}`,borderRadius:8,padding:"14px",cursor:"pointer",fontSize:16,fontWeight:700}}>
              {opt.label}
            </button>
          ))}
        </div>}
      </div>
      <div style={{display:"flex",gap:12}}>
        {index>0&&<button style={{...gBtn,flex:1}} onClick={()=>setState({...state,index:index-1})}>← Zurück</button>}
        {index<quiz.length-1
          ?<button style={{background:C.blue,color:"#fff",border:"none",borderRadius:8,padding:"12px",fontWeight:700,fontSize:14,cursor:"pointer",flex:1}} onClick={()=>setState({...state,index:index+1})}>Weiter →</button>
          :<button style={{background:C.green,color:"#fff",border:"none",borderRadius:8,padding:"12px",fontWeight:700,fontSize:14,cursor:"pointer",flex:1}} onClick={submit}>Abgeben ✓</button>
        }
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// SCHÜLER APP
// ══════════════════════════════════════════════════════════════════════
function SchuelerApp({schueler,material,onLogout}) {
  const [view,setView]=useState("home");
  const [selItem,setSelItem]=useState(null);
  const pct=Math.round((Object.values(schueler.themen||{}).filter(v=>v===2).length/ALL_ITEMS.length)*100);

  const openLernmaterial=key=>{setSelItem(key);setView("lernmaterial");};
  const goBack=()=>{
    if(view==="lernmaterial") setView("diagramm");
    else setView("home");
  };

  return (
    <div style={{minHeight:"100vh",background:C.bg,fontFamily:"'Segoe UI',sans-serif",color:C.text}}>
      <div style={{background:C.surface,borderBottom:`3px solid ${C.blue}`,padding:"14px 20px",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,zIndex:10}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{fontWeight:900,fontSize:20}}>FahrSchul<span style={{color:C.accent}}>Pro</span></div>
          <span style={{background:C.blue,color:"#fff",borderRadius:20,padding:"2px 10px",fontSize:11,fontWeight:700}}>SCHÜLER</span>
        </div>
        <div style={{display:"flex",gap:8}}>
          {view!=="home"&&<button onClick={goBack} style={gBtn}>← Zurück</button>}
          <button onClick={onLogout} style={gBtn}>Abmelden</button>
        </div>
      </div>

      {view==="home"&&(
        <div style={{maxWidth:680,margin:"0 auto",padding:"24px 16px"}}>
          <div style={{marginBottom:24}}>
            <div style={{fontSize:26,fontWeight:900,marginBottom:4}}>Hallo, {schueler.name.split(" ")[0]}! 👋</div>
            <div style={{color:C.muted,fontSize:15}}>Schön dass du da bist.</div>
          </div>

          {/* Ausbildungskarte – OHNE Statistik */}
          <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:20,padding:24,marginBottom:16}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
              <div>
                <div style={{fontSize:12,color:C.muted,fontWeight:700,letterSpacing:1,marginBottom:4}}>📊 AUSBILDUNGSDIAGRAMM</div>
                <div style={{fontWeight:900,fontSize:20}}>Mein Fortschritt</div>
                <div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:6}}>
                  {(schueler.info?.klassen||[]).map(k=><span key={k} style={{fontSize:11,background:"rgba(58,134,255,0.2)",color:C.blue,borderRadius:5,padding:"2px 8px",fontWeight:700}}>Kl. {k}</span>)}
                </div>
              </div>
              <div style={{position:"relative",flexShrink:0}}>
                <ProgressRing pct={pct}/>
                <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:900}}>{pct}%</div>
              </div>
            </div>

            {/* Stufen Mini Übersicht */}
            <div style={{display:"flex",gap:6,marginBottom:16,overflowX:"auto",paddingBottom:4}}>
              {AUSBILDUNG.map(s=>{
                const keys=s.gruppen.flatMap(g=>g.items.map(i=>`${s.id}::${g.name}::${i}`));
                const sBeh=keys.filter(k=>(schueler.themen||{})[k]===2).length;
                const sPct=Math.round((sBeh/keys.length)*100);
                return (
                  <div key={s.id} style={{background:sPct>0?s.color+"22":"rgba(255,255,255,0.05)",border:`1px solid ${sPct>0?s.color+"44":C.border}`,borderRadius:10,padding:"8px 12px",textAlign:"center",flexShrink:0,minWidth:72}}>
                    <div style={{fontSize:18}}>{s.icon}</div>
                    <div style={{fontSize:10,fontWeight:700,color:sPct>0?s.color:C.muted,marginTop:2}}>{s.label}</div>
                    <div style={{fontSize:11,fontWeight:900,color:sPct>0?s.color:C.muted}}>{sPct}%</div>
                  </div>
                );
              })}
            </div>

            {(schueler.info?.notizen||[]).length>0&&(
              <div style={{background:C.surface,borderRadius:10,padding:"12px 14px",borderLeft:`3px solid ${C.blue}`,marginBottom:14}}>
                <div style={{fontSize:11,color:C.muted,marginBottom:4,fontWeight:600}}>LETZTE NOTIZ VOM FAHRLEHRER</div>
                <div style={{fontSize:13,lineHeight:1.5}}>{schueler.info.notizen[0].text}</div>
              </div>
            )}
            <button onClick={()=>setView("diagramm")} style={{...pBtn,width:"100%",padding:"12px",fontSize:15}}>Alle Stufen & Lernmaterial →</button>
          </div>

          {/* Prüfungsreife – Coming Soon */}
          <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:16,padding:"18px 20px",marginBottom:12,opacity:0.7}}>
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:6}}>
              <span style={{fontSize:28}}>🏆</span>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,fontSize:16}}>Prüfungsreife</div>
                <div style={{color:C.muted,fontSize:13}}>Automatische Auswertung deiner Ausbildungsreife</div>
              </div>
              <span style={{background:"rgba(139,92,246,0.2)",color:"#8b5cf6",borderRadius:20,padding:"3px 10px",fontSize:11,fontWeight:700,flexShrink:0}}>Coming Soon</span>
            </div>
          </div>

          {/* Theorie Lektionen – Coming Soon */}
          <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:16,padding:"18px 20px",marginBottom:12,opacity:0.7}}>
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:10}}>
              <span style={{fontSize:28}}>📖</span>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,fontSize:16}}>Theorie Lektionen</div>
                <div style={{color:C.muted,fontSize:13}}>14 Lektionen für die Theorieprüfung</div>
              </div>
              <span style={{background:"rgba(139,92,246,0.2)",color:"#8b5cf6",borderRadius:20,padding:"3px 10px",fontSize:11,fontWeight:700,flexShrink:0}}>Coming Soon</span>
            </div>
            <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
              {[1,2,3,4,5,6,7,8,9,10,11,12,13,14].map(n=>(
                <div key={n} style={{width:36,height:36,borderRadius:8,background:C.surface,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:700,color:C.muted}}>
                  {n}
                </div>
              ))}
            </div>
          </div>

          {/* Fahrlehrer */}
          <div onClick={()=>setView("ueber")} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:16,padding:"16px 18px",marginBottom:12,cursor:"pointer",display:"flex",alignItems:"center",gap:14,transition:"border-color .2s"}}
            onMouseEnter={e=>e.currentTarget.style.borderColor=C.orange}
            onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
            <div style={{width:52,height:52,borderRadius:"50%",background:`linear-gradient(135deg,${C.orange},#d97706)`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0}}>👨‍🏫</div>
            <div style={{flex:1}}><div style={{fontWeight:700,fontSize:15,marginBottom:2}}>Dein Fahrlehrer</div><div style={{color:C.muted,fontSize:13}}>Infos & Kontakt</div></div>
            <span style={{color:C.muted,fontSize:22}}>›</span>
          </div>

          {/* Social Media & Kontakte */}
          <div style={{fontWeight:700,fontSize:15,marginBottom:10,color:C.muted}}>Social Media & Kontakt</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            {[
              {icon:"📸",label:"Instagram",handle:"@fahrschulpro",bg:"linear-gradient(135deg,#833ab4,#fd1d1d,#fcb045)"},
              {icon:"🎵",label:"TikTok",handle:"@fahrschulpro",bg:"#010101",border:`1px solid #333`},
              {icon:"▶️",label:"YouTube",handle:"Fahrschul Videos",bg:"#ff0000"},
              {icon:"💬",label:"WhatsApp",handle:"Direkt schreiben",bg:"#25d366"},
            ].map((s,i)=>(
              <a key={i} href="#" style={{background:s.bg,border:s.border||"none",borderRadius:14,padding:"16px 14px",textDecoration:"none",color:"#fff",display:"flex",flexDirection:"column",gap:6}}>
                <div style={{fontSize:26}}>{s.icon}</div>
                <div style={{fontWeight:800,fontSize:14}}>{s.label}</div>
                <div style={{fontSize:11,opacity:0.75}}>{s.handle}</div>
              </a>
            ))}
          </div>
        </div>
      )}
      {view==="diagramm"&&<DiagrammView schueler={schueler} onToggleItem={()=>{}} onOpenLernmaterial={openLernmaterial} material={material} isLehrer={false}/>}
      {view==="lernmaterial"&&selItem&&<LernmaterialView itemKey={selItem} material={material} setMaterial={null} isLehrer={false}/>}
      {view==="ueber"&&<UeberView/>}
    </div>
  );
}

function UeberView() {
  return (
    <div style={{maxWidth:680,margin:"0 auto",padding:"24px 16px"}}>
      <div style={{fontWeight:900,fontSize:22,marginBottom:20}}>👨‍🏫 Dein Fahrlehrer</div>
      <div style={{background:C.card,borderRadius:16,padding:24,border:`1px solid ${C.border}`}}>
        <div style={{display:"flex",gap:16,alignItems:"center",marginBottom:18}}>
          <div style={{width:72,height:72,borderRadius:"50%",background:`linear-gradient(135deg,${C.orange},#d97706)`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,flexShrink:0}}>👨‍🏫</div>
          <div><div style={{fontWeight:900,fontSize:20}}>Max Mustermann</div><div style={{color:C.accent,fontSize:13,fontWeight:700,marginTop:2}}>Fahrlehrer & Inhaber</div></div>
        </div>
        <div style={{color:C.muted,fontSize:14,lineHeight:1.8,marginBottom:18}}>Lorem ipsum dolor sit amet. Hier steht dein persönlicher Text.</div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          {["🚗 Klasse B","🏍 Klasse A","✅ 10+ Jahre","⭐ Top Bewertungen","📍 Musterstadt"].map((tag,i)=>(
            <span key={i} style={{background:C.surface,color:C.muted,border:`1px solid ${C.border}`,borderRadius:20,padding:"4px 12px",fontSize:12,fontWeight:700}}>{tag}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

const statCard={background:C.card,borderRadius:14,padding:"16px 12px",border:`1px solid ${C.border}`,textAlign:"center",transition:"border-color .2s"};
const gBtn={background:"transparent",color:C.muted,border:`1px solid ${C.border}`,borderRadius:8,padding:"8px 14px",cursor:"pointer",fontWeight:600,fontSize:13};
const pBtn={background:C.accent,color:"#fff",border:"none",borderRadius:8,padding:"10px 20px",cursor:"pointer",fontWeight:700,fontSize:14};
const lbl={fontSize:13,color:C.muted,display:"block",marginBottom:6};
const inp={width:"100%",boxSizing:"border-box",border:`1.5px solid ${C.border}`,borderRadius:8,padding:"10px 14px",fontSize:14,color:C.text,background:C.bg,outline:"none"};
