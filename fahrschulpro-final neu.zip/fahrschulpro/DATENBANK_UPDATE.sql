-- Bestehende Tabellen löschen und neu aufbauen
DROP TABLE IF EXISTS themen_status CASCADE;
DROP TABLE IF EXISTS fahrstunden CASCADE;
DROP TABLE IF EXISTS themen_material CASCADE;
DROP TABLE IF EXISTS schueler CASCADE;

-- Schüler Tabelle
CREATE TABLE schueler (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  pin TEXT NOT NULL,
  erstellt_am TIMESTAMP DEFAULT NOW()
);

-- Schüler Info (Akte)
CREATE TABLE schueler_info (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  schueler_id UUID REFERENCES schueler(id) ON DELETE CASCADE UNIQUE,
  klassen TEXT[] DEFAULT '{}',
  sehhilfe TEXT DEFAULT 'Keine',
  theorie BOOLEAN DEFAULT false,
  fahrlehrer TEXT DEFAULT '',
  aktualisiert_am TIMESTAMP DEFAULT NOW()
);

-- Notizen (ersetzt Fahrstunden)
CREATE TABLE notizen (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  schueler_id UUID REFERENCES schueler(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  datum DATE DEFAULT CURRENT_DATE,
  erstellt_am TIMESTAMP DEFAULT NOW()
);

-- Ausbildungsstand (Füllbalken 0/1/2)
CREATE TABLE ausbildungsstand (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  schueler_id UUID REFERENCES schueler(id) ON DELETE CASCADE,
  item_key TEXT NOT NULL,
  wert INTEGER DEFAULT 0,
  aktualisiert_am TIMESTAMP DEFAULT NOW(),
  UNIQUE(schueler_id, item_key)
);

-- Sicherheit
ALTER TABLE schueler ENABLE ROW LEVEL SECURITY;
ALTER TABLE schueler_info ENABLE ROW LEVEL SECURITY;
ALTER TABLE notizen ENABLE ROW LEVEL SECURITY;
ALTER TABLE ausbildungsstand ENABLE ROW LEVEL SECURITY;

CREATE POLICY "allow_all" ON schueler FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON schueler_info FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON notizen FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all" ON ausbildungsstand FOR ALL USING (true) WITH CHECK (true);
